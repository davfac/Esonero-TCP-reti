/*
 ============================================================================
 Name        : Server.c
 Author      : Davide
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include "Protocol.h"
#include <stdio.h>
#include <stdlib.h> // for atoi()
#include <math.h>
#include <stdint.h>
#include <ctype.h>


//Sum operation
int sum(int a, int b){
	return (a + b);
}

//Subtraction operation
int sub(int a, int b){
	return (a - b);
}

//Division operation
float division(float a, float b){
	if(b == 0){
		return NAN; //Not a number
	}
	return (a / b);
}

//Multiplication operation
int molt(int a, int b){
	return (a * b);
}

//Function that checks the symbol sent from a client
float operation(char symbol, int first, int second){
	float result = 0;
	if(symbol == '+'){
		result = (float)sum(first, second);
	}
	if(symbol == '-') {
		result = (float)sub(first,second);
	}
	if(symbol == 'x'){
		result = (float)molt(first, second);
	}
	if(symbol == '/') {
		result = division((float)first, (float)second);
	}
	return result;
}

void errorhandler(char *errorMessage) {
	printf ("%s", errorMessage);
}

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

//Procedure that splits a float number in 2 parts(the part before comma and after comma)
void controlPoint(float result, answer* resultStruct) {
	char buf[15] = "";
	char bufFirstNumber[10] = "";
	char bufSecondNumber[10] = "";
	int i = 0;
	int j = 0;

	sprintf(buf, "%.3f", result);
	for( i = 0; buf[i] != '.'; i++) {
		if(buf[i] != '.') bufFirstNumber[i] = buf[i];
	}
	while(buf[i] != '\0') {
		if(buf[i] != '.' && buf[i] != '\0') {
			bufSecondNumber[j] = buf[i];
			j++;
		}
		i++;
	}
	resultStruct->resultBeforeComma = atoi(bufFirstNumber);
	resultStruct->resultAfterComma = atoi(bufSecondNumber);
}

//Function that send a struct to a client
int sendStruct(int socketServer, int socketClient, answer result, int lung_struct){
	int returnValue = 0;
	if (send(socketClient, (void*)&result, lung_struct, 0) != lung_struct)
	{
		errorhandler("send() sent a different number of bytes than expected");
		system("pause");
		closesocket(socketServer);
		clearwinsock();
		returnValue = -1;
	}
	return returnValue;
}

int main(int argc, char *argv[]) {

	int port;
	int returnValue = 0;
	if (argc > 1) {
		port = atoi(argv[1]); //If argument specified convert argument to binary
	}
	else
		port = PROTOPORT; //Use default port number
	if (port < 0) {
		printf("bad port number %s \n", argv[1]);
		system("pause");
		return 0;
	}
#if defined WIN32 // initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != 0) {
		errorhandler("Error at WSAStartup()\n");
		return 0;
	}
#endif
	// SOCKET CREATION
	int my_socket;
	my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (my_socket < 0) {
		errorhandler("Socket creation failed.\n");
		system("pause");
		clearwinsock();
		return -1;
	}
	//ASSIGNING IP ADDRESS TO A NEW SOCKET
	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad)); //Ensures that extra bytes contain 0
	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr("127.0.0.1");
	sad.sin_port = htons(port); /* Converts values between the host and network byte order. Specifically, htons() converts 16-bit quantities
								from host byte order to network byte order. */
	if (bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {
		errorhandler("bind() failed.\n");
		system("pause");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}
	// SETTING LISTENING SOCKET
	if (listen (my_socket, QLEN) < 0) {
		errorhandler("listen() failed.\n");
		system("pause");
		closesocket(my_socket);
		clearwinsock();
		return -1;
	}
	// ACCEPTING NEW CONNECTION
	struct sockaddr_in cad; //Structure for the client address
	int client_socket = 0; //Socket descriptor for the client
	int client_len; //The size of the client address
	printf("Waiting for a client to connect...\n");

	while (1) {
		float resultOperation = 0;
		int bytes_rcvd = 0;
		int total_bytes_rcvd = 0;
		msg message = {0};
		client_len = sizeof(cad); //Set the size of the client address

		if ((client_socket = accept(my_socket, (struct sockaddr *)&cad, &client_len)) < 0) {
			errorhandler("accept() failed.\n");
			system("pause");
			// CHIUSURA DELLA CONNESSIONE
			closesocket(client_socket);
			clearwinsock();
			return 0;
		}
		printf("\nConnection established with %s\n", inet_ntoa(cad.sin_addr));

		if(total_bytes_rcvd < sizeof(msg) - 1 ) {
			while((bytes_rcvd = recv(client_socket, (void*)&message,sizeof(msg), 0)) > 0 ) {
				answer resultStruct = {0};
				total_bytes_rcvd += bytes_rcvd; // Keep tally of total bytes
				message.first = ntohl(message.first);
				message.second = ntohl(message.second);
				resultOperation = operation(message.symbol, message.first, message.second);
				//It checks that result is NaN (example 0/0)
				if(!isnan(resultOperation)) {
					if(message.symbol == '/') {
						controlPoint(resultOperation, &resultStruct);
						resultStruct.resultBeforeComma = htonl(resultStruct.resultBeforeComma);
						resultStruct.resultAfterComma = htonl(resultStruct.resultAfterComma);
					}
					else {
						resultStruct.resultBeforeComma = (int)resultOperation;
						resultStruct.resultBeforeComma = htonl(resultStruct.resultBeforeComma);
					}
				}
				//Division by 0
				else {
					resultStruct.error = 's';
				}
				returnValue = sendStruct(my_socket,client_socket, resultStruct, sizeof(answer));
				if(returnValue == -1) {
					return -1;
				}
			}
		}
		closesocket(client_socket);
	}// end-while
}// end-main
