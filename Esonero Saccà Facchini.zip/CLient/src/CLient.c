/*
 ============================================================================
 Name        : CLient.c
 Author      : Davide
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include "Protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

void errorhandler(char *error_message) {
	printf("%s",error_message);
}

//You can choose to use personal IP address and port or standard ones
void adressInput(int argc, char *argv[], struct sockaddr_in* socket) {
	char address[13];
	int port;

	if (argc > 1) {
		strcpy(address, argv[1]);
		port = atoi(argv[2]); // If argument specified convert argument to binary
	}
	else{
		strcpy(address, "127.0.0.1");
		port = PROTOPORT; // Use default port number
	}
	if(port < 0){
		printf("bad port number %s \n", argv[2]);
	}
	memset(socket, 0, sizeof(&socket));
	socket->sin_family = AF_INET;
	socket->sin_addr.s_addr = inet_addr(address); // Server IP
	socket->sin_port = htons(port);
}

//It controls that the user input is a number
int controlInput(char *input) {
	int control = 0;
	for(int i = 0; i < strlen(input); i++) {
		if(!isdigit(input[i])) {
			control = -1;
		}
		if(input[i-1] == '-' && i-1 == 0 && isdigit(input[i])){
			control = 0;
		}
	}
	return control;
}

//Procedure that checks if the user input is empty
int controlEmptyInput(char *input) {
	int control = 0;

	for(int i = 0; i < strlen(input); i++) {
		if(input[i] != ' ') {
			control = 1;
		}
	}
	return control;
}

//Procedure to write the operation from the standard input and tokenizes it.
void inputOperation(msg *message, int socketClient){
	char inputFirst[10] = {0};
	char inputSecond[10] = {0};
	size_t n = 0;

	do {
		char input[50] = "";
		char * tokens[50] = {};
		memset(inputFirst, 0, 10);
		memset(inputSecond, 0, 10);
		printf("\nINSERT [sign] [operand1] [operand2]: ");
		gets(input);
		n = 0;
		if(controlEmptyInput(input) == 1) {
			for (char * p = strtok(input, " "); p; p = strtok(NULL, " "))
			{
				if (n >= 3)
				{
					//Maximum number of storable tokens exceeded
					break;
				}
				tokens[n++] = p;
			}
			message->symbol = *tokens[0];
		}
		if(message->symbol != '=' && (n == 3)) {
			strcpy(inputFirst, tokens[1]);
			strcpy(inputSecond, tokens[2]);
			if(controlInput(inputFirst) == -1 || controlInput(inputSecond) == -1) {
				printf("Insert a valid input\n");
			}
		}
		if(n != 3 && message->symbol != '=') {
			printf("Insert a valid input\n");
		}
		if(message->symbol != '+' && message->symbol != '/' && message->symbol != 'x' && message->symbol != '-' && message->symbol != '=') {
			printf("Insert a valid sign\n");
		}
	}while((message->symbol != '+' && message->symbol != '/' && message->symbol != 'x' && message->symbol != '-' && message->symbol != '=')
			|| (controlInput(inputFirst) == -1 || controlInput(inputSecond) == -1) || ((n != 3) && (message->symbol != '=')));
	message->first = atoi(inputFirst);
	message->second = atoi(inputSecond);
	fflush(stdin);
}

//Function that sends a struct to a server
int sendStruct(int socketClient, msg message, int lung_struct){
	int returnValue = 0;
	if (send(socketClient, (void*)&message, lung_struct, 0) != lung_struct)
	{
		errorhandler("send() sent a different number of bytes than expected");
		system("pause");
		closesocket(socketClient);
		clearwinsock();
		returnValue = -1;
	}
	return returnValue;
}

//Function that checks if a number received is negative
int controlNegativeNumber(msg message) {
	int control = 0;
	if(message.first < 0 || message.second < 0) {
		control = -1;
	}
	if(message.first < 0 && message.second < 0) {
		control = 0;
	}
	return control;
}

int main(int argc, char *argv[]) {
	msg message = {0};
	int returnValue = 0;
	int controlInputSign = 0;

#if defined WIN32
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2 ,2), &wsa_data);
	if (result != 0) {
		printf ("error at WSASturtup\n");
		return -1;
	}
#endif

	//SOCKET CREATION
	int c_socket;
	c_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (c_socket < 0) {
		errorhandler("Socket creation failed.\n");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}

	//SERVER IP ADDRESS CONSTRUCTION
	struct sockaddr_in sad;
	adressInput(argc,argv, &sad);

	//Connection to server
	if (connect(c_socket, (struct sockaddr *)&sad, sizeof(sad))< 0)
	{
		errorhandler("Failed to connect.\n");
		system("PAUSE");
		closesocket(c_socket);
		clearwinsock();
		return -1;
	}
	printf("Type a query using the example format: + 14 31\n");
	printf("The valid operators are: (+) (-) (x) (/)\n");
	printf("to close the client, type: (=)\n");

	do {
		int bytes_rcvd;
		int total_bytes_rcvd = 0;
		answer resultOperation = {0};
		// SENDING DATA TO A SERVER
		inputOperation(&message, c_socket);
		if(message.symbol == '=') {
			closesocket(c_socket);
			clearwinsock();
			printf("\n"); // Print a final linefeed
			system("pause");
			return 0;
		}
		controlInputSign = controlNegativeNumber(message);
		message.first = htonl(message.first);
		message.second = htonl(message.second);
		returnValue = sendStruct(c_socket, message, sizeof(msg));
		if(returnValue == -1) {
			return -1;
		}
		// RECEIVING DATA FROM SERVER
		while (total_bytes_rcvd < sizeof(resultOperation)) {
			if ((bytes_rcvd = recv(c_socket, (char*)&resultOperation, sizeof(answer), 0)) <= 0)
			{
				errorhandler("recv() failed or connection closed prematurely");
				system("pause");
				closesocket(c_socket);
				clearwinsock();
				return -1;
			}
			total_bytes_rcvd += bytes_rcvd; // Keep tally of total bytes
		}

		//If operation is a division, client receives two results that representing a float split in two integers
		if(message.symbol == '/') {
			//Control the value on the message received from the server
			if(resultOperation.error != 's') {
				resultOperation.resultBeforeComma = ntohl(resultOperation.resultBeforeComma);
				resultOperation.resultAfterComma = ntohl(resultOperation.resultAfterComma);
				//If operation is division, result before comma is 0 (example -0,15) and the operation is negative, insert the negative sign
				if(resultOperation.resultBeforeComma == 0 && controlInputSign == -1) {
					printf("RESULT: -%d,%03d\n", resultOperation.resultBeforeComma, resultOperation.resultAfterComma);
				}
				else {
					printf("RESULT: %d,%03d\n", resultOperation.resultBeforeComma, resultOperation.resultAfterComma);
				}
			}
			else {
				printf("Input error: impossible to divide by 0\n");
			}
		}
		else {
			resultOperation.resultBeforeComma = ntohl(resultOperation.resultBeforeComma);
			resultOperation.resultAfterComma = ntohl(resultOperation.resultAfterComma);
			printf("RESULT: %d\n", resultOperation.resultBeforeComma);
		}
	}while(message.symbol != '=');
}
