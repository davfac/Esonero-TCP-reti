/*
 * Protocol.h
 *
 *  Created on: 11 nov 2021
 *      Author: Homepc
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define BUFFERSIZE 512
#define PROTOPORT 27015 //Default protocol port number
#define QLEN 5 //Size of request queue

typedef struct{
	char symbol;
	int first;
	int second;
}msg;

typedef struct{
	int resultBeforeComma;
	int resultAfterComma;
	char error;
}answer;

#endif /* PROTOCOL_H_ */
